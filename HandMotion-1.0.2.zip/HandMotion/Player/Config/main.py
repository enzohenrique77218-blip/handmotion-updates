
import sys
import pygame

# HandMotion - Configurações
GAME_NAME = "HandMotion"
VERSION = "1.0.0"

WIDTH = 960
HEIGHT = 540
FPS = 60

BACKGROUND = (14, 17, 26)
WHITE = (240, 244, 255)
BLUE = (70, 145, 255)
GRAY = (145, 155, 175)


def main():
    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(f"{GAME_NAME} v{VERSION}")

    title_font = pygame.font.SysFont("segoeui", 64, bold=True)
    version_font = pygame.font.SysFont("segoeui", 26)
    info_font = pygame.font.SysFont("segoeui", 18)

    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        screen.fill(BACKGROUND)

        # Linha decorativa
        pygame.draw.rect(
            screen,
            BLUE,
            (WIDTH // 2 - 90, 175, 180, 5),
            border_radius=3,
        )

        title = title_font.render(GAME_NAME, True, WHITE)
        version = version_font.render(
            f"Versão {VERSION}", True, BLUE
        )
        info = info_font.render(
            "Pressione ESC para sair", True, GRAY
        )

        screen.blit(
            title,
            title.get_rect(center=(WIDTH // 2, 245)),
        )
        screen.blit(
            version,
            version.get_rect(center=(WIDTH // 2, 310)),
        )
        screen.blit(
            info,
            info.get_rect(center=(WIDTH // 2, 470)),
        )

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
